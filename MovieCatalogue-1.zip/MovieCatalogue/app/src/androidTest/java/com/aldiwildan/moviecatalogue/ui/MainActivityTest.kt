package com.aldiwildan.moviecatalogue.ui

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.rule.ActivityTestRule
import com.aldiwildan.moviecatalogue.R
import com.aldiwildan.moviecatalogue.utils.DataDummy
import org.junit.Rule
import org.junit.Test
import java.lang.Thread.sleep

class MainActivityTest {

    private val dataDummy = DataDummy
    private val dummyMovie = dataDummy.generateDataDummyMovies()
    private val dummyTvShow = dataDummy.generateDataDummyTvShow()

    @get:Rule
    var activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun loadMovies() {
        onView(withId(R.id.rv_movies)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movies)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dummyMovie.size
            )
        )
    }

    @Test
    fun loadMovieDetail() {
        onView(withId(R.id.rv_movies)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                5,
                click()
            )
        )
        onView(withId(R.id.img_poster)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_title)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_title)).check(matches(withText(dummyMovie[5].title)))
        onView(withId(R.id.tv_item_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_rating)).check(matches(withText(dummyMovie[5].rating.toString())))
        onView(withId(R.id.tv_item_release)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_release)).check(matches(withText("Released at " + dummyMovie[5].release)))
        onView(withId(R.id.tv_item_overview_value)).perform(scrollTo(), click())
        onView(withId(R.id.tv_item_overview_value)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_overview_value)).check(matches(withText(dummyMovie[5].overview)))
    }

    @Test
    fun loadTvShows() {
        onView(withId(R.id.rv_movies)).perform(swipeLeft())
        sleep(1000)
        onView(withId(R.id.rv_tv_shows)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tv_shows)).perform(
            RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dummyTvShow.size
            )
        )
    }

    @Test
    fun loadTvShowDetail() {
        onView(withId(R.id.rv_movies)).perform(swipeLeft())
        sleep(1000)
        onView(withId(R.id.rv_tv_shows)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
        onView(withId(R.id.img_poster)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_title)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_title)).check(matches(withText(dummyTvShow[0].title)))
        onView(withId(R.id.tv_item_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_rating)).check(matches(withText(dummyTvShow[0].rating.toString())))
        onView(withId(R.id.tv_item_release)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_release)).check(matches(withText("Released at " + dummyTvShow[0].release)))
        onView(withId(R.id.tv_item_overview_value)).perform(scrollTo(), click())
        onView(withId(R.id.tv_item_overview_value)).check(matches(isDisplayed()))
        onView(withId(R.id.tv_item_overview_value)).check(matches(withText(dummyTvShow[0].overview)))
    }
}
