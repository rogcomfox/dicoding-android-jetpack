package com.aldiwildan.moviecatalogue.ui.tvshow

import com.aldiwildan.moviecatalogue.utils.DataDummy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel

    private val dummyTvShow = DataDummy.generateDataDummyTvShow()[0]
    private val tvShowId = dummyTvShow.id

    @Before
    fun setup() {
        viewModel = TvShowViewModel()
        viewModel.setSelectedTvShow(tvShowId)
    }

    @Test
    fun getTvShows() {
        val tvShowEntities = viewModel.getTvShows()
        assertNotNull(tvShowEntities)
        assertEquals(10, tvShowEntities.size)
    }

    @Test
    fun setSelectedTvShow() {
        val tvShow = viewModel.getTvShow()
        assertNotNull(tvShow)
        assertEquals(tvShowId, tvShow!!.id)
    }

    @Test
    fun getTvShow() {
        val tvShow = viewModel.getTvShow()
        assertNotNull(tvShow)
        assertEquals(tvShowId, tvShow!!.id)
        assertEquals(dummyTvShow.title, tvShow.title)
        assertEquals(dummyTvShow.overview, tvShow.overview)
        assertEquals(dummyTvShow.release, tvShow.release)
        assertEquals(dummyTvShow.rating, tvShow.rating)
        assertEquals(dummyTvShow.poster, tvShow.poster)
    }
}