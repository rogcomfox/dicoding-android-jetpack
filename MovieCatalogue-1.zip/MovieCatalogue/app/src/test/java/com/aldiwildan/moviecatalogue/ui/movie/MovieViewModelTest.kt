package com.aldiwildan.moviecatalogue.ui.movie

import com.aldiwildan.moviecatalogue.utils.DataDummy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel

    private val dummyMovie = DataDummy.generateDataDummyMovies()[0]
    private val movieId = dummyMovie.id

    @Before
    fun setup() {
        viewModel = MovieViewModel()
        viewModel.setSelectedMovie(movieId)
    }

    @Test
    fun getMovies() {
        val movieEntities = viewModel.getMovies()
        assertNotNull(movieEntities)
        assertEquals(10, movieEntities.size)
    }

    @Test
    fun setSelectedMovie() {
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movieId, movie!!.id)
    }

    @Test
    fun getMovie() {
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movieId, movie!!.id)
        assertEquals(dummyMovie.title, movie.title)
        assertEquals(dummyMovie.overview, movie.overview)
        assertEquals(dummyMovie.release, movie.release)
        assertEquals(dummyMovie.rating, movie.rating)
        assertEquals(dummyMovie.poster, movie.poster)
    }
}