package com.aldiwildan.moviecatalogue.ui.movie

import androidx.lifecycle.ViewModel
import com.aldiwildan.moviecatalogue.data.MovieEntity
import com.aldiwildan.moviecatalogue.utils.DataDummy

class MovieViewModel : ViewModel() {

    private lateinit var movieId: String

    fun getMovies(): ArrayList<MovieEntity> = DataDummy.generateDataDummyMovies()

    fun setSelectedMovie(id: String) {
        this.movieId = id
    }

    fun getMovie(): MovieEntity? {
        var movie: MovieEntity? = null
        for (movieEntity in DataDummy.generateDataDummyMovies()) {
            if (movieEntity.id == movieId) {
                movie = movieEntity
            }
        }
        return movie
    }
}
