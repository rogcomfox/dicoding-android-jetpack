package com.aldiwildan.moviecatalogue.ui.tvshow

import androidx.lifecycle.ViewModel
import com.aldiwildan.moviecatalogue.data.MovieEntity
import com.aldiwildan.moviecatalogue.utils.DataDummy

class TvShowViewModel : ViewModel() {

    private lateinit var tvShowId: String

    fun getTvShows(): ArrayList<MovieEntity> = DataDummy.generateDataDummyTvShow()

    fun setSelectedTvShow(id: String) {
        this.tvShowId = id
    }

    fun getTvShow(): MovieEntity? {
        var tvShow: MovieEntity? = null
        for (tvShowEntity in DataDummy.generateDataDummyTvShow()) {
            if (tvShowEntity.id == tvShowId) {
                tvShow = tvShowEntity
            }
        }
        return tvShow
    }

}
