package com.aldiwildan.moviecatalogue.data

data class MovieEntity(
    val id: String,
    val title: String,
    val overview: String,
    val rating: Float,
    val release: String,
    val poster: String
)
