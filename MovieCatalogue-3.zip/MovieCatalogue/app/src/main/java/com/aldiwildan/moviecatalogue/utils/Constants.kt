package com.aldiwildan.moviecatalogue.utils

import com.aldiwildan.moviecatalogue.BuildConfig

object Constants {
    const val API_KEY = BuildConfig.API_KEY
    const val BASE_URL = BuildConfig.BASE_URL
    const val IMG_URL = BuildConfig.IMG_URL
}