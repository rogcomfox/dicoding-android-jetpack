package com.aldiwildan.moviecatalogue.data.source.remote.response

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}