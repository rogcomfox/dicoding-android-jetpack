package com.aldiwildan.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}