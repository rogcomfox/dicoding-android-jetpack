package com.aldiwildan.moviecatalogue.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.aldiwildan.moviecatalogue.data.source.MovieRepository
import com.aldiwildan.moviecatalogue.data.source.local.entity.MovieEntity
import com.aldiwildan.moviecatalogue.data.source.remote.response.TvShowResponse
import com.aldiwildan.moviecatalogue.utils.DataDummy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel

    private val dummyTvShow = DataDummy.generateDataDummyTvShow()
    private val tvShowId = dummyTvShow[0].id

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieRepository: MovieRepository

    @Mock
    private lateinit var tvShowDetailObserver: Observer<TvShowResponse>

    @Mock
    private lateinit var tvShowObserver: Observer<ArrayList<TvShowResponse>>

    @Before
    fun setup() {
        viewModel = TvShowViewModel(movieRepository)
        viewModel.setSelectedTvShow(tvShowId)
    }

    @Test
    fun getTvShows() {
        val tvShows = MutableLiveData<ArrayList<TvShowResponse>>()
        tvShows.value = dummyTvShow

        `when`(movieRepository.getAllTvShows()).thenReturn(tvShows)
        val tvShowEntities = viewModel.getTvShows().value
        verify(movieRepository).getAllTvShows()
        assertNotNull(tvShowEntities)
        assertEquals(10, tvShowEntities?.size)

        viewModel.getTvShows().observeForever(tvShowObserver)
        verify(tvShowObserver).onChanged(dummyTvShow)
    }

    @Test
    fun setSelectedTvShow() {
        val tvShow = MutableLiveData<TvShowResponse>()
        tvShow.value = dummyTvShow[0]

        `when`(movieRepository.getTvShow(tvShowId)).thenReturn(tvShow)
        val tvShowEntities = viewModel.getTvShow().value
        verify(movieRepository).getTvShow(tvShowId)
        assertNotNull(tvShow)
        assertEquals(tvShowId, tvShowEntities?.id)

        viewModel.getTvShow().observeForever(tvShowDetailObserver)
        verify(tvShowDetailObserver).onChanged(dummyTvShow[0])
    }

    @Test
    fun getTvShow() {
        val tvShow = MutableLiveData<TvShowResponse>()
        tvShow.value = dummyTvShow[0]

        `when`(movieRepository.getTvShow(tvShowId)).thenReturn(tvShow)
        val tvShowEntities = viewModel.getTvShow().value
        verify(movieRepository).getTvShow(tvShowId)
        assertNotNull(tvShow)
        assertEquals(tvShowId, tvShow.value?.id)
        assertEquals(dummyTvShow[0].title, tvShowEntities?.title)
        assertEquals(dummyTvShow[0].overview, tvShowEntities?.overview)
        assertEquals(dummyTvShow[0].release, tvShowEntities?.release)
        assertEquals(dummyTvShow[0].rating, tvShowEntities?.rating)
        assertEquals(dummyTvShow[0].poster, tvShowEntities?.poster)

        viewModel.getTvShow().observeForever(tvShowDetailObserver)
        verify(tvShowDetailObserver).onChanged(dummyTvShow[0])
    }
}