package com.aldiwildan.moviecatalogue.data.source

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.aldiwildan.moviecatalogue.data.source.remote.RemoteDataSource
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse
import com.aldiwildan.moviecatalogue.data.source.remote.response.TvShowResponse
import com.aldiwildan.moviecatalogue.utils.DataDummy
import com.aldiwildan.moviecatalogue.utils.LiveDataTestUtil
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.doAnswer
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito.mock

@Suppress("UNCHECKED_CAST")
class MovieRepositoryTest {

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = mock(RemoteDataSource::class.java)
    private val movieRepository = FakeMovieRepository(remote)

    private val movieResponse = DataDummy.generateDataDummyMovies() as List<MovieResponse>
    private val tvShowResponse = DataDummy.generateDataDummyTvShow() as List<TvShowResponse>

    private val movieId = movieResponse[0].id
    private val tvShowId = tvShowResponse[0].id

    @Test
    fun getAllMovies() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadMoviesCallback)
                .onSuccess(movieResponse)
            null
        }.`when`(remote).getAllMovies(any())
        val movieEntities = LiveDataTestUtil.getValue(movieRepository.getAllMovies())
        verify(remote).getAllMovies(any())
        assertNotNull(movieEntities)
        assertEquals(movieResponse.size.toLong(), movieEntities.size.toLong())
    }

    @Test
    fun getAllTvShows() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[0] as RemoteDataSource.LoadTvShowsCallback)
                .onSuccess(tvShowResponse)
            null
        }.`when`(remote).getAllTvShows(any())
        val tvShowEntities = LiveDataTestUtil.getValue(movieRepository.getAllTvShows())
        verify(remote).getAllTvShows(any())
        assertNotNull(tvShowEntities)
        assertEquals(tvShowResponse.size.toLong(), tvShowEntities.size.toLong())
    }

    @Test
    fun getMovie() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[1] as RemoteDataSource.LoadMovieDetailCallback)
                .onSuccess(movieResponse[0])
            null
        }.`when`(remote).getMovieDetail(eq(movieId), any())
        val movieEntities = LiveDataTestUtil.getValue(movieRepository.getMovie(movieId))
        verify(remote).getMovieDetail(eq(movieId), any())
        assertNotNull(movieEntities)
        assertEquals(movieResponse[0].id, movieEntities.id)
    }

    @Test
    fun getTvShow() {
        doAnswer { invocationOnMock ->
            (invocationOnMock.arguments[1] as RemoteDataSource.LoadTvShowDetailCallback)
                .onSuccess(tvShowResponse[0])
            null
        }.`when`(remote).getTvShowDetail(eq(tvShowId), any())
        val tvShowEntities = LiveDataTestUtil.getValue(movieRepository.getTvShow(tvShowId))
        verify(remote).getTvShowDetail(eq(tvShowId), any())
        assertNotNull(tvShowEntities)
        assertEquals(tvShowResponse[0].id, tvShowEntities.id)
    }
}