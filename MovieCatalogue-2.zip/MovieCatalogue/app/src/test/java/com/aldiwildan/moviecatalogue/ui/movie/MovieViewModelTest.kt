package com.aldiwildan.moviecatalogue.ui.movie

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.aldiwildan.moviecatalogue.data.source.MovieRepository
import com.aldiwildan.moviecatalogue.data.source.local.entity.MovieEntity
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse
import com.aldiwildan.moviecatalogue.utils.DataDummy
import com.nhaarman.mockitokotlin2.verify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner
import java.util.*

@RunWith(MockitoJUnitRunner::class)
class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel

    private val dummyMovie = DataDummy.generateDataDummyMovies()
    private val movieId = dummyMovie[0].id

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var movieRepository: MovieRepository

    @Mock
    private lateinit var movieDetailObserver: Observer<MovieResponse>

    @Mock
    private lateinit var moviesObserver: Observer<ArrayList<MovieResponse>>

    @Before
    fun setup() {
        viewModel = MovieViewModel(movieRepository)
        viewModel.setSelectedMovie(movieId)
    }

    @Test
    fun getMovies() {
        val movies = MutableLiveData<ArrayList<MovieResponse>>()
        movies.value = dummyMovie

        `when`(movieRepository.getAllMovies()).thenReturn(movies)
        val movieEntities = viewModel.getMovies().value
        verify(movieRepository).getAllMovies()
        assertNotNull(movieEntities)
        assertEquals(10, movieEntities?.size)

        viewModel.getMovies().observeForever(moviesObserver)
        verify(moviesObserver).onChanged(dummyMovie)
    }

    @Test
    fun setSelectedMovie() {
        val movie = MutableLiveData<MovieResponse>()
        movie.value = dummyMovie[0]

        `when`(movieRepository.getMovie(movieId)).thenReturn(movie)
        val movieEntities = viewModel.getMovie().value
        verify(movieRepository).getMovie(movieId)
        assertNotNull(movie)
        assertEquals(movieId, movieEntities?.id)

        viewModel.getMovie().observeForever(movieDetailObserver)
        verify(movieDetailObserver).onChanged(dummyMovie[0])
    }

    @Test
    fun getMovie() {
        val movie = MutableLiveData<MovieResponse>()
        movie.value = dummyMovie[0]

        `when`(movieRepository.getMovie(movieId)).thenReturn(movie)
        val movieEntities = viewModel.getMovie().value
        verify(movieRepository).getMovie(movieId)
        assertNotNull(movie)
        assertEquals(movieId, movieEntities?.id)
        assertEquals(dummyMovie[0].title, movieEntities?.title)
        assertEquals(dummyMovie[0].overview, movieEntities?.overview)
        assertEquals(dummyMovie[0].release, movieEntities?.release)
        assertEquals(dummyMovie[0].rating, movieEntities?.rating)
        assertEquals(dummyMovie[0].poster, movieEntities?.poster)

        viewModel.getMovie().observeForever(movieDetailObserver)
        verify(movieDetailObserver).onChanged(dummyMovie[0])
    }
}