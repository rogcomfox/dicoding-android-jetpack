package com.aldiwildan.moviecatalogue.ui.tvshow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aldiwildan.moviecatalogue.data.source.MovieRepository
import com.aldiwildan.moviecatalogue.data.source.remote.response.TvShowResponse

class TvShowViewModel(private val movieRepository: MovieRepository) : ViewModel() {

    private var tvShowId: Int? = null

    fun getTvShows(): LiveData<ArrayList<TvShowResponse>> = movieRepository.getAllTvShows()

    fun setSelectedTvShow(id: Int) {
        this.tvShowId = id
    }

    fun getTvShow(): LiveData<TvShowResponse> = movieRepository.getTvShow(tvShowId)

}
