package com.aldiwildan.moviecatalogue.ui.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.aldiwildan.moviecatalogue.data.source.MovieRepository
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse

class MovieViewModel(private val movieRepository: MovieRepository) : ViewModel() {

    private var movieId: Int? = null

    fun getMovies(): LiveData<ArrayList<MovieResponse>> = movieRepository.getAllMovies()

    fun setSelectedMovie(id: Int) {
        this.movieId = id
    }

    fun getMovie(): LiveData<MovieResponse> = movieRepository.getMovie(movieId)
}
