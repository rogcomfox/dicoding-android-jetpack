package com.aldiwildan.moviecatalogue.di

import com.aldiwildan.moviecatalogue.data.source.MovieRepository
import com.aldiwildan.moviecatalogue.data.source.remote.RemoteDataSource
import com.aldiwildan.moviecatalogue.network.ApiClient

object Injection {

    fun provideRepository(): MovieRepository {
        val apiClient = ApiClient().create()
        val remoteDataSource = RemoteDataSource.getInstance(apiClient)
        return MovieRepository.getInstance(remoteDataSource)
    }
}