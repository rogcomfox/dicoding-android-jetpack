package com.aldiwildan.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse
import com.aldiwildan.moviecatalogue.data.source.remote.response.TvShowResponse

interface MovieDataSource {

    fun getAllMovies(): LiveData<ArrayList<MovieResponse>>

    fun getAllTvShows(): LiveData<ArrayList<TvShowResponse>>

    fun getMovie(movieId: Int?): LiveData<MovieResponse>

    fun getTvShow(tvShowId: Int?): LiveData<TvShowResponse>
}