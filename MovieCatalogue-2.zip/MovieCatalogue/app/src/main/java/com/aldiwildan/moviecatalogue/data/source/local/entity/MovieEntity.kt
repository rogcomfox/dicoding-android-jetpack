package com.aldiwildan.moviecatalogue.data.source.local.entity

data class MovieEntity(
    val id: Int,
    val title: String?,
    val overview: String?,
    val rating: Double?,
    val release: String?,
    val poster: String?
)
