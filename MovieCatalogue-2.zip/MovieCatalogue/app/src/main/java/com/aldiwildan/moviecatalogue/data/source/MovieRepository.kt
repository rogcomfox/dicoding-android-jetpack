package com.aldiwildan.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.aldiwildan.moviecatalogue.data.source.remote.RemoteDataSource
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse
import com.aldiwildan.moviecatalogue.data.source.remote.response.TvShowResponse

class MovieRepository private constructor(private val remoteDataSource: RemoteDataSource) :
    MovieDataSource {

    companion object {
        @Volatile
        private var instance: MovieRepository? = null

        fun getInstance(remoteData: RemoteDataSource): MovieRepository =
            instance ?: synchronized(this) {
                instance ?: MovieRepository(remoteData)
            }
    }

    override fun getAllMovies(): LiveData<ArrayList<MovieResponse>> {
        val movieResult = MutableLiveData<ArrayList<MovieResponse>>()
        remoteDataSource.getAllMovies(object : RemoteDataSource.LoadMoviesCallback {

            override fun onSuccess(response: List<MovieResponse>?) {
                val movieList = ArrayList<MovieResponse>()
                for (res in response!!) {
                    movieList.add(res)
                }
                movieResult.postValue(movieList)
            }

            override fun onFailure(ex: Exception) {
                TODO("Not yet implemented")
            }
        })
        return movieResult
    }

    override fun getAllTvShows(): LiveData<ArrayList<TvShowResponse>> {
        val tvShowResult = MutableLiveData<ArrayList<TvShowResponse>>()
        remoteDataSource.getAllTvShows(object : RemoteDataSource.LoadTvShowsCallback {

            override fun onSuccess(response: List<TvShowResponse>?) {
                val tvShowList = ArrayList<TvShowResponse>()
                for (res in response!!) {
                    tvShowList.add(res)
                }
                tvShowResult.postValue(tvShowList)
            }

            override fun onFailure(ex: Exception) {
                TODO("Not yet implemented")
            }
        })
        return tvShowResult
    }

    override fun getMovie(movieId: Int?): LiveData<MovieResponse> {
        val movieResult = MutableLiveData<MovieResponse>()
        remoteDataSource.getMovieDetail(movieId, object : RemoteDataSource.LoadMovieDetailCallback {
            override fun onSuccess(response: MovieResponse?) {
                movieResult.postValue(response)
            }

            override fun onFailure(ex: Exception) {
                TODO("Not yet implemented")
            }

        })

        return movieResult
    }

    override fun getTvShow(tvShowId: Int?): LiveData<TvShowResponse> {
        val tvShowResult = MutableLiveData<TvShowResponse>()
        remoteDataSource.getTvShowDetail(tvShowId,
            object : RemoteDataSource.LoadTvShowDetailCallback {
                override fun onSuccess(response: TvShowResponse?) {
                    tvShowResult.postValue(response)
                }

                override fun onFailure(ex: Exception) {
                    TODO("Not yet implemented")
                }

            })

        return tvShowResult
    }
}