package com.aldiwildan.moviecatalogue.ui.movie

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.aldiwildan.moviecatalogue.R
import com.aldiwildan.moviecatalogue.data.source.remote.response.MovieResponse
import com.aldiwildan.moviecatalogue.utils.Constants
import com.aldiwildan.moviecatalogue.viewmodel.ViewModelFactory
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.activity_movie_detail.*

class MovieDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE_ID = "extra_movie_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance()
        val viewModel = ViewModelProvider(
            this,
            factory
        )[MovieViewModel::class.java]

        val extras = intent.extras
        if (extras != null) {
            val movieId = extras.getInt(EXTRA_MOVIE_ID)
            if (movieId > 0) {
                viewModel.setSelectedMovie(movieId)
                pb_detail.visibility = View.VISIBLE
                viewModel.getMovie().observe(this, Observer { movie ->
                    pb_detail.visibility = View.GONE
                    tv_loading.visibility = View.GONE
                    cl_detail.visibility = View.VISIBLE
                    populateMovie(movie)
                })
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun populateMovie(movie: MovieResponse?) {
        tv_item_title.text = movie!!.title
        tv_item_overview_value.text = movie.overview
        tv_item_rating.text = movie.rating.toString()
        tv_item_release.text = "Released at " + movie.release

        Glide.with(this)
            .load(Constants.IMG_URL + movie.poster)
            .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
            .error(R.drawable.ic_error)
            .into(img_poster)
    }
}
